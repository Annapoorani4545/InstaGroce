from flask import render_template, flash, redirect, request, session, url_for
from GroceryStore import app, db
from GroceryStore.forms import NewUserRegistration, UserLogin, AdminLogin, Categories, Products, SearchProducts
from GroceryStore.models import User, Category, Product
from datetime import datetime
from flask_login import login_user, logout_user, current_user, login_required
from sqlalchemy import and_

@app.route("/admin_Applogin", methods=['GET', 'POST'])
def admin_Applogin():
    form1 = AdminLogin()
    if form1.validate_on_submit():
        admintrue = User.query.filter_by(email=form1.email.data, password=form1.password.data, is_admin=True).first()
        if admintrue:
            login_user(admintrue)
            flash('Successful Admin Login!!', 'success')
            return redirect(url_for('customer_products'))
        else:
            flash('Login failed. You may have entered Invalid email or password, Please Check again.', 'danger')
            session['login_failed'] = True

    if session.pop('login_failed', False):
        flash('Login failed. You may have entered Invalid email or password, Please Check again', 'danger')

    return render_template("loginasadmin.html", title='Admin Login page', form=form1)



@app.route("/NewUser", methods=['GET', 'POST'])
def NewUser():
    form2 = NewUserRegistration()

    if form2.validate_on_submit():
        cusname = form2.username.data
        useremail = form2.email.data
        passec = form2.password.data
        is_admin = form2.is_admin.data

        new_cus = User(username=cusname, email=useremail, password=passec)

        if is_admin:
            new_cus.is_admin = True

        db.session.add(new_cus)
        db.session.commit()

        flash(f'Dear User, your account {cusname} is created! You can Log in now', 'success')
        return redirect(url_for('Applogin'))

    return render_template("appregistration.html", title='Registration for New Account', form=form2)


@app.route("/", methods=['GET', 'POST'])
@app.route("/Applogin", methods=['GET', 'POST'])
def Applogin():
    form3 = UserLogin()
    if form3.validate_on_submit():
        exiuser = User.query.filter_by(email=form3.email.data, password=form3.password.data, is_admin=False).first()
        if exiuser:
            login_user(exiuser)
            flash('Admin login successful!' if exiuser.is_admin else 'Login successful!', 'success')
            return redirect(url_for('customer_products'))
        else:
            flash('Login failed. You may have entered Invalid email or password, please check again.', 'danger')
            session['login_failed'] = True

    if session.pop('login_failed', False):
        flash('Login failed. You may have entered Invalid email or password, please check again.', 'danger')

    return render_template("iglogin.html", title='Login', form=form3)


@app.route("/add_product_to_cart/<int:product_id>", methods=['POST'])
@login_required
def add_product_to_cart(product_id):
    addprod = Product.query.get_or_404(product_id)
    reqquant = int(request.form.get('quantity'))

    if reqquant <= 0:
        flash('Please enter valid Quantity, greater than 0.', 'danger')
        return redirect(url_for('customer_products'))

    if addprod.units <= 0:
        flash(f"Sorry the product '{addprod.name}' you're looking for is currently out of stock, please try later.", 'danger')
        return redirect(url_for('customer_products'))

    if reqquant > addprod.units:
        flash(f"Sorry, The quantity available for product '{addprod.name}' is only {addprod.units} at the present, please come back later for the remaining quantity required.", 'danger')
        return redirect(url_for('customer_products'))

    demcus = current_user
    prev_ord = demcus.orders.filter_by(id=product_id).first()

    if prev_ord:
        prev_ord.quantity += reqquant
    else:
        new_ord = Product.query.get_or_404(product_id)
        new_ord.units -= reqquant
        new_ord.quantity = reqquant
        demcus.orders.append(new_ord)

    db.session.commit()

    flash(f'Success! {reqquant} {addprod.name}(s) added to your cart.', 'success')
    return redirect(url_for('customer_products'))


@app.route("/search_product", methods=['GET', 'POST'])
@login_required
def search_product():
    thissec = Category.query.all()
    find_form = SearchProducts()
    find_form.category.choices = [(category.id, category.name) for category in thissec]

    if request.method == 'POST' and find_form.validate():
        filtering = []

        sec_id = find_form.category.data
        if sec_id:
            filtering.append(Product.category_id == sec_id)

        bud_price = find_form.max_price.data
        if bud_price:
            filtering.append(Product.rate_per_unit <= bud_price)

        max_start = find_form.begin_date.data
        if max_start:
            filtering.append(Product.manufacture_date >= max_start)

        henc = db.session.query(Product, Category.name).join(Category).filter(and_(*filtering))
        resulting_products = henc.all()

        return render_template("filtered_results.html", products=resulting_products, title='Results')

    return render_template("find.html", help_form=find_form, title='Product Search New')


@app.route("/customer_products", methods=['GET', 'POST'])
@login_required
def customer_products():
    set = Category.query.all()
    res_set = {category: Product.query.filter_by(category_id=category.id).all() for category in set}

    findd_form = SearchProducts()

    if findd_form.validate_on_submit():
        dem_bud = findd_form.max_price.data
        l_old = findd_form.begin_date.data

        filter_criteria = []

        if dem_bud:
            filter_criteria.append(Product.rate_per_unit <= dem_bud)
        if l_old:
            filter_criteria.append(Product.manufacture_date >= l_old)

        r_products = Product.query.filter(and_(*filter_criteria)).all()
        res_set = {'Filtered Results': r_products}

    return render_template("in_order.html", products_by_category=res_set, help_form=findd_form, title='Customer Products')


@app.route("/customer_account", methods=['GET', 'POST'])
@login_required
def customer_account():
    cuse = current_user
    itm = cuse.orders.all()
    fin_amt = sum(cart_item.rate_per_unit * cart_item.quantity for cart_item in itm)

    return render_template("appuser.html", user=cuse, cart_items=itm, total_amount=fin_amt, title='Customer Account')


from flask import flash, redirect, url_for, session
from flask import flash, redirect, url_for
from flask_login import logout_user

@app.route("/Applogout")
def Applogout():
    if current_user.is_authenticated:
        logout_user()
        flash('Successfully Logged out!', 'info')
    else:
        flash('User is not logged in.', 'warning')

    return redirect(url_for('Applogin'))


@app.route("/category_management", methods=['GET', 'POST'])
@login_required
def category_management():
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    form4 = Categories()

    if request.method == 'POST' and form4.validate():
        plus_sec = Category(name=form4.name.data)
        db.session.add(plus_sec)
        db.session.commit()
        flash('New Category added successfully!', 'success')
        return redirect(url_for('category_management'))

    modsec = Category.query.all()
    return render_template("mysections.html", form=form4, categories=modsec, title='Edit/Add Categories')

@app.route("/adding_new_category", methods=['GET', 'POST'])
@login_required
def adding_new_category():
    if not current_user.is_admin:
        return _handle_admin_permission_error()

    form5 = Categories()

    if form5.validate_on_submit():
        _add_new_category(form5.name.data)
        flash('New Category added successfully!', 'success')
        return _redirect_to_category_management()

    return render_template("add_category.html", form=form5, title='Adding New Category')

def _handle_admin_permission_error():
    flash("Only Admin has permission to access this page.", 'danger')
    return redirect(url_for('Applogin'))

def _add_new_category(category_name):
    new_category = Category(name=category_name)
    db.session.add(new_category)
    db.session.commit()

def _redirect_to_category_management():
    return redirect(url_for('category_management'))

from flask import render_template, flash, redirect, url_for, request
from flask_login import login_required, current_user

@app.route("/modify_existing_category/<int:category_id>", methods=['GET', 'POST'])
@login_required
def modify_existing_category(category_id):
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    ntcat = Category.query.get_or_404(category_id)
    form6 = Categories(obj=ntcat)

    if request.method == 'POST' and form6.validate():
        ntcat.name = form6.name.data
        db.session.commit()
        flash('Success! Category Updated', 'success')
        return redirect(url_for('category_management'))

    return render_template("modify_section.html", form=form6, category=ntcat, title='Modify Existing Category')


@app.route("/remove_category/<int:category_id>", methods=['POST'])
@login_required
def remove_category(category_id):
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    mtcat = Category.query.get_or_404(category_id)

    try:
        db.session.delete(mtcat)
        db.session.commit()
        flash('Success! Category Removed', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {str(e)}', 'danger')

    return redirect(url_for('category_management'))


@app.route("/Appcart", methods=['GET', 'POST'])
@login_required
def Appcart():
    cusm = current_user
    mart = cusm.orders.all()
    bill = sum(cart_item.rate_per_unit * cart_item.quantity for cart_item in mart)

    if request.method == 'POST':
        cusm.orders = []
        db.session.commit()
        flash('Success! Your Order Purchase is complete! Your cart is now empty.', 'success')
        return redirect(url_for('purchasing_completed'))

    return render_template("mycart.html", cart_items=mart, total_amount=bill, title='Cart Page')


@app.route("/product_management", methods=['GET', 'POST'])
@login_required
def product_management():
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    form7 = Products()
    form7.category.choices = [(category.id, category.name) for category in Category.query.all()]

    if form7.validate_on_submit():
        n_prod = Product(
            name=form7.name.data,
            manufacture_date=form7.manufacture_date.data,
            expiry_date=form7.expiry_date.data,
            rate_per_unit=form7.rate_per_unit.data,
            category_id=form7.category.data,
            units=form7.units.data
        )
        db.session.add(n_prod)
        db.session.commit()
        flash('New Product added successfully!', 'success')
        return redirect(url_for('product_management'))

    modifprod = (
        db.session.query(Product, Category.name)
        .join(Category)
        .all()
    )

    return render_template("control_products.html", form=form7, products=modifprod, title='Product Management')

@app.route("/remove_product/<int:product_id>", methods=['POST'])
@login_required
def remove_product(product_id):
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    eprod = Product.query.get_or_404(product_id)

    for user in eprod.purchaser:
        user.orders.remove(eprod)

    db.session.delete(eprod)
    db.session.commit()
    flash('Success! Product Removed', 'success')
    return redirect(url_for('product_management'))


@app.route("/modify_existing_product/<int:product_id>", methods=['GET', 'POST'])
@login_required
def modify_existing_product(product_id):
    if not current_user.is_admin:
        flash("Only Admin has permission to access this page.", 'danger')
        return redirect(url_for('Applogin'))

    soprod = Product.query.get_or_404(product_id)
    form9 = Products(obj=soprod)

    seco = Category.query.all()

    form9.category.choices = [(category.id, category.name) for category in seco]

    if form9.validate_on_submit():

        soprod.name = form9.name.data
        soprod.manufacture_date = form9.manufacture_date.data
        soprod.expiry_date = form9.expiry_date.data
        soprod.rate_per_unit = form9.rate_per_unit.data
        soprod.category_id = form9.category.data
        soprod.units = form9.units.data
        db.session.commit()
        flash('Success! Product Updated', 'success')
        return redirect(url_for('product_management'))

    return render_template("modify_product.html", form=form9, product=soprod, categories=seco, title='Modify Existing Product')



from flask import render_template, request
from sqlalchemy import and_


@app.route("/purchasing_completed", methods=['GET', 'POST'])
@login_required
def purchasing_completed():
    uot = User.query.get(current_user.id)
    uot.orders = []
    db.session.commit()

    return render_template("order_done.html", title='Completed Purchase')

@app.route("/empty_cart", methods=['POST'])
@login_required
def empty_cart():
    iot = current_user
    for cart_item in iot.orders:
        cart_item.quantity = 0
    db.session.commit()
    flash('Success! Cart Emptied.', 'success')
    return redirect(url_for('Appcart'))



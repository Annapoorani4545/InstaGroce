
# Upgrade the PIP
- `pip install --upgrade pip`

# To install the requirements
- `pip install -r requirements.txt`

# To run the development server
- type `python main.py`
